import { action, observable } from 'mobx';

export class BlockStore {}
