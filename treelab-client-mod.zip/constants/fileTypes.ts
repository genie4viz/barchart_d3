export const IMAGE_TYPES = ['png', 'gif', 'jpg', 'jpeg', 'bmp', 'svg'];
