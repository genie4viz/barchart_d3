export const Resolvers = {
  Mutation: {},
};

export const Defaults = {
  language: 'en',
};
