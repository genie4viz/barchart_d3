import { css } from 'emotion';

export const AddRowWrapper = css`
  padding: 3px;
  border: 1px solid pink;
`;
