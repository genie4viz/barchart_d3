import { css } from '@emotion/core';

export const FieldSwitchCSS = css`
  margin: 15px 0 15px 15px;
`;

export const DefaultCSS = css`
  width: 264px;
  margin: 15px 0px 0px 15px;
`;
