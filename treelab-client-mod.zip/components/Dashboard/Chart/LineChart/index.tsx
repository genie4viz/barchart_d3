import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';
import { IChartData } from '..';
import useDimensions from '../UseDimensions';

interface IProps {
    data: IChartData;    
    isCountChart?: boolean;
    idx?: number;
}
const LineChart: React.SFC<IProps> = (props) => {
    const { data, isCountChart, idx} = props;
    
    const idx_str = idx != null ? idx : '';

    const svgRef = useRef(null);    
    const [containerRef, dimens] = useDimensions();    
    const width = Math.max(dimens.width, 280), height = Math.max(dimens.height, 280);

    useEffect(() => drawChart(), [dimens, data]);

    const drawChart = () => {
        if (data == null) return;

        d3.select(svgRef.current).selectAll("*").remove();

        let margins = { top: 20, left: 20, bottom: 30, right: 30 }, c_data: any;
        if(isCountChart){
            c_data = d3.nest()
                .key((d: any) => d.value)
                .rollup((v: any) => v.length)
                .entries(data.values);
        }else{
            c_data = data.values;
        }
        let min: number = 0,// d3.min
            max: any = d3.max(c_data, (d: any) => d.value);

        let x: any = d3
                .scaleBand()
                .range([0, width - margins.right - margins.left])
                .domain(c_data.map((d: any) => isCountChart ? d.key : d.label))
                .padding(0.3),
            y = d3
                .scaleLinear()
                .domain([min, max])
                .rangeRound([height - margins.bottom, margins.top + margins.bottom]),
            xAxis = d3
                .axisBottom(x)
                .tickSize(-height + margins.top + margins.bottom),
            yAxis = d3
                .axisLeft(y)
                .tickSize(-width + margins.right + margins.left)
                .ticks(5);

        let xArea = d3.select(svgRef.current)
            .append('g');
        
        xArea
            .attr('class', 'x axis')
            .attr('transform', "translate(50," + (height - margins.bottom) + ")")
            .call(xAxis)
            .select('.domain')
            .remove();

        let yArea = d3.select(svgRef.current)
            .append('g');
        yArea
            .attr('class', 'y axis')
            .attr('transform', "translate(50, 0)")
            .call(yAxis)
            .select('.domain')
            .remove();

        d3.select(svgRef.current)
            .selectAll('.tick line')
            .attr('stroke', '#ccc');

        let valueline: any = d3.line()
            .x((d: any) => isCountChart ? x(d.key) + x.bandwidth()/2 : x(d.label) + x.bandwidth()/2)
            .y((d: any) => y(d.value))
            .curve(d3.curveMonotoneX)

        d3.select(svgRef.current)
            .append("g")
            .attr('transform', 'translate(50, 0)')
            .append("path")
            .data([c_data])
            .attr("class", "line")
            .attr("fill", "none")
            .attr("stroke", 'steelblue')
            .attr("stroke-width", 2)
            .attr("d", valueline);

        const tooltip = d3.select(svgRef.current).append('g');
        
        d3.select(svgRef.current)
            .append("g")
            .attr('transform', 'translate(50, 0)')
            .selectAll(".dot")
            .data(c_data)
            .enter().append("circle")
            .attr("class", (d, i) => "dot" + idx_str + i)
            .attr("fill", 'steelblue')
            .attr("cursor", "pointer")
            .attr("cx", (d: any) => isCountChart ? x(d.key) + x.bandwidth()/2 : x(d.label) + x.bandwidth()/2)
            .attr("cy", (d: any) => y(d.value))
            .attr("r", 5)
            .on("mouseover", (d: any, i) => {
                console.log('hey', '.dot' + idx_str + i)
                d3.select('.dot' + idx_str + i).attr('r', 7);
                if(isCountChart){
                    tooltip.attr('transform', 'translate(' + (50 + x(d.key) + x.bandwidth()/2) + ',' + y(d.value) +')').call(callout, d);
                }else{
                    tooltip.attr('transform', 'translate(' + (50 + x(d.label) + x.bandwidth()/2) + ',' + y(d.value) +')').call(callout, d);
                }
                tooltip.raise();
            })
            .on("mouseout", (d, i) => {
                d3.select('.dot' + idx_str + i).attr('r', 5);
                tooltip.call(callout, null);
            })

        d3.select(svgRef.current)
            .append("text")            
            .attr("x", margins.left)
            .attr("y", margins.top)            
            .attr('font-size', '16pt')
            .attr('fill', 'black')
            .style("text-anchor", "start")
            .text(data.name)
        
        xArea.append("text")            
            .attr("x", width/2)
            .attr("y", margins.bottom)            
            .attr('font-size', '12pt')
            .attr('fill', 'black')
            .style("text-anchor", "end")
            .text(data.XAxis)

        yArea.append("text")
            .attr("transform", "rotate(-90)")
            .attr("x", -height/2)
            .attr("y", -45)
            .attr("dy", ".71em")
            .attr('font-size', '12pt')
            .attr('fill', 'black')
            .style("text-anchor", "middle")
            .text(data.YAxis)
        
        const callout = (g: any, d: any) => {
            if (!d){
                g.selectAll("*").remove();
                return g.style('display', 'none');
            }
            
            g.style('display', null).style('pointer-events', 'none')

            const path = g.selectAll("path")
                .data([null])
                .join("path")
                .attr("fill", 'steelblue')
                .attr("stroke", "white");

            let strText = isCountChart ? '(' + d.key + ':' + d.value + ')' : '(' + d.label + ':' + d.value + ')';
            
            const text = g.selectAll("text")
                .data([null])
                .join("text")
                .call((text: any) => text
                    .selectAll("tspan")
                    .data((strText + "").split(/\n/))
                    .join("tspan")
                        .attr('fill', 'white')
                        .attr('text-anchor', 'start')                        
                        .attr("x", 0)
                        .attr("y", (d: any, i: any) => `${i * 1.1}em`)                            
                        .text((d: any) => d));

            const {width: tw, height: th} = text.node().getBBox();            
            let curX = isCountChart ? x(d.key) + x.bandwidth() : x(d.label) + x.bandwidth();
            if((curX + tw + 20) > width - margins.right){
                text.attr("transform", 'translate(' + (- tw - 10) + ',0)')
                    .attr('dy','0.3em')
                path
                    .attr("transform", 'translate(0,0)')
                    .attr("d", 'M0,0l-5,-5v' + (-(th - 10)/2) + 'h' + (-tw - 10) + 'v' + th + 'h' + (tw + 10) + 'v' + (-(th- 10)/2) +'l5,-5z')
            }else{
                text.attr("transform", 'translate(10,0)').attr('dy','0.3em')
                path.attr("d", 'M0,0l5,-5v' + (-(th - 10)/2) + 'h' + (tw + 10) + 'v' + th + 'h' + (-(tw + 10)) + 'v' + (-(th- 10)/2) +'l-5,-5z')
            }
        }
    }
    return (
        <div ref={containerRef}>
            <svg className={"lineChart" + idx_str} ref={svgRef} width={width} height={height} />
        </div>
    );
}

export default LineChart;
