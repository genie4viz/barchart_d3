import React from 'react';
import { BarStyle } from './styled';

export interface IProps {

}

const SeperateBar: React.FC<IProps> = ({ }) => (
    <div css={BarStyle}>

    </div>
);

export default SeperateBar;
