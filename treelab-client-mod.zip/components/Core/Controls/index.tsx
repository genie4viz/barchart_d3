import React from 'react';
import { Container } from './styled';

const CoreControls: React.FC = () => <Container>Controls TBD</Container>;

export default CoreControls;
