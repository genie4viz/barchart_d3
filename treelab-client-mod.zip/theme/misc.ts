export const MISC = {
  modalRadius: '8px',
};
