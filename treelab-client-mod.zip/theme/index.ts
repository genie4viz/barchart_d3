import { COLORS } from './color';
import { MISC } from './misc';

export const theme = {
  color: COLORS,
  misc: MISC,
};
