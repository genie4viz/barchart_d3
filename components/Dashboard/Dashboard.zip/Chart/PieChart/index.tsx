import React, { createRef } from 'react';
import * as d3 from 'd3';
import { IChartData } from '@app/components/Dashboard/Chart';

interface IProps {
    data: IChartData[];
    width: number;
    height: number;
}

interface IState {
    data: IChartData[];
    width: number;
    height: number;
}

class PieChart extends React.Component<IProps, IState> {
    private ref: React.RefObject<SVGSVGElement>;

    constructor(props: any) {
        super(props);
        this.state = {
            data: [],
            width: 0,
            height: 0
        };
        this.ref = createRef();
    }
    static getDerivedStateFromProps(props: IProps, state: IState){
        return {
            data: props.data,
            width: props.width,
            height: props.height
        }
    }
    componentDidUpdate() {
        const { data, width, height } = this.state;
        if (this.state.data == null) return;

        let radius = Math.min(width, height) / 2;

        let arc: any = d3.arc()
            .outerRadius(radius - 10)
            .innerRadius(0);

        let labelArc = d3.arc()
            .outerRadius(radius - radius / 3)
            .innerRadius(radius - radius / 3);

        let pie = d3.pie()
            .sort(null)
            .value((d: any) => d.value);

        d3.select(this.ref.current).selectAll("*").remove();

        let svg = d3.select(this.ref.current).append("g")
            .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

        let g = svg.selectAll(".arc")
            .data(pie(data))
            .enter().append("g")
            .attr("class", "arc");

        g.append("path")
            .attr("d", arc)
            .attr("stroke", 'white')
            .attr("stroke-width", 2)
            .style("fill", d => d.data.color);

        g.append("text")
            .attr("transform", (d: any) => "translate(" + labelArc.centroid(d) + ")")
            .attr("dy", ".35em")
            .attr('fill', "white")
            .attr('font-size', 12)
            .attr('text-align', 'middle')
            .text((d: any) => (d.data.name))

    }
    render() {
        const { width, height } = this.state;        

        return (
            <svg className="pieChart" ref={this.ref}
                width={width} height={height}>
            </svg>
        );
    }
}

export default PieChart;
