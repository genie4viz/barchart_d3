
export interface IChartData {
    name: string;
    value: number;
    color: string;
}