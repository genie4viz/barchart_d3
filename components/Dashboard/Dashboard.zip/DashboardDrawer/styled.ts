import { css } from '@emotion/core';
import styled from '@emotion/styled';

export const ButtonStyle = (theme: any) => css`
  width: 100%;
  margin-bottom: 24px;
  margin-top: 20px;
`;

export const PanelStyle = css`
  margin-top: 24px;
`;

export const Content = styled.div`
  width: 396px;
  margin-top: 24px;
  margin-bottom: 32px;
`;

export const InputItem = css`
  margin-top: 12px;
  margin-bottom: 16px;
`;
