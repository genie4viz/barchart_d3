import React, { Fragment } from 'react';
import { ButtonStyle, PanelStyle, Content, InputItem } from './styled';

import Button from '@app/components/Button';

import DrawerFrame from '@app/components/Dashboard/DrawerFrame';
import Panel from '@app/components/Dashboard/Panel';
import SeperateBar from '@app/components/Dashboard/SeperateBar';
import { compose } from 'react-apollo';
import { FormattedMessage, InjectedIntl, injectIntl } from 'react-intl';
import { glyphs } from '@app/components/Icon';
import { P2 } from '@app/components/Shared/Typescale';

import { Field, Form } from 'react-final-form';
import FormInputSelect from '@app/components/Form/FormInputSelect';
import FormInputSwitch from '@app/components/Form/FormInputSwitch';
import FormInputSelectButton from '@app/components/Form/FormInputSelectButton';

import PieChart from '@app/components/Dashboard/Chart/PieChart';
import BarChart from '@app/components/Dashboard/Chart/BarChart';

import { FakeData } from '@app/components/Dashboard/Chart/fake';

import { observable } from 'mobx';
import { inject, observer } from 'mobx-react';
import Category, { ICategory } from './Category';
import { IStyleItem } from './Category/StyleItem';

enum DrawerPages {
    BLOCKS = 'block',
    STYLE = 'style',
    CREAT_BLOCK = 'create_block'
}

export interface IProps {
    onClose: () => void;
    categories: ICategory[];
    intl: InjectedIntl;
}

interface IState {
    isLoaded: boolean;
}

@observer
class DashboardDrawer extends React.Component<IProps, IState> {
    @observable private pageShow: DrawerPages = DrawerPages.BLOCKS;
    @observable private selectedStyleId: string = "";

    constructor(props: any) {
        super(props)

        this.onClickStyleItem = this.onClickStyleItem.bind(this)

        this.setState({
            isLoaded: false,
        });
    }

    componentDidMount() {
        this.setState({
            isLoaded: true,
        });
    }

    private onClickStyleItem(item: IStyleItem) {
        this.selectedStyleId = item.id;
    }

    public render() {
        const { onClose, intl: { formatMessage }, categories } = this.props;
        return (
            <Fragment>
                {this.pageShow === DrawerPages.BLOCKS &&
                    <DrawerFrame title={formatMessage({ id: 'pageDashboard.drawerBlock' })} onClose={onClose} >
                        <SeperateBar />
                        <Panel css={PanelStyle} width={"436px"}>
                            <PieChart data={FakeData} width={436} height={300} />
                        </Panel>
                        <Panel css={PanelStyle} width={"436px"}>
                            <BarChart data={FakeData} width={436} height={300} />
                        </Panel>
                        <Button css={ButtonStyle} onClick={() => { this.pageShow = DrawerPages.STYLE; }}>
                            <FormattedMessage id="pageDashboard.createBlock" />
                        </Button>
                    </DrawerFrame>
                }
                {this.pageShow === DrawerPages.STYLE &&
                    <DrawerFrame title={formatMessage({ id: 'pageDashboard.drawerStyle' })} onClose={onClose} >
                        <SeperateBar />
                        {categories.map((category) => (
                            <Category key={category.id} category={category} onClick={this.onClickStyleItem} selectedId={this.selectedStyleId} />
                        ))}
                        <Button css={ButtonStyle} onClick={() => { this.pageShow = DrawerPages.CREAT_BLOCK; }} isDisabled={this.selectedStyleId == ""}>
                            <FormattedMessage id="pageDashboard.next" />
                        </Button>
                    </DrawerFrame>
                }
                {this.pageShow === DrawerPages.CREAT_BLOCK &&
                    <Form
                        initialValues={{}}
                        onSubmit={() => { }}
                        render={({ handleSubmit }) => (
                            <form onSubmit={handleSubmit}>
                                <DrawerFrame title={formatMessage({ id: 'pageDashboard.drawerCreateBlock' })} onClose={onClose} >

                                    <SeperateBar />
                                    <Content>
                                        <Field
                                            titleId="pageDashboard.drawerCore"
                                            css={InputItem}
                                            name="dropdownCore"
                                            component={FormInputSelect as any}
                                            options={[
                                                { name: 'one', value: '1' },
                                                { name: 'two', value: '2' },
                                                { name: 'three', value: '3' }
                                            ]}
                                        />
                                        <Field
                                            titleId="pageDashboard.drawerTable"
                                            css={InputItem}
                                            name="dropdownTable"
                                            component={FormInputSelect as any}
                                            options={[
                                                { name: 'one', value: '1' },
                                                { name: 'two', value: '2' },
                                                { name: 'three', value: '3' }
                                            ]}
                                        />
                                        <Field
                                            titleId="pageDashboard.drawerView"
                                            css={InputItem}
                                            name="dropdownView"
                                            component={FormInputSelect as any}
                                            options={[
                                                { name: 'one', value: '1' },
                                                { name: 'two', value: '2' },
                                                { name: 'three', value: '3' }
                                            ]}
                                        />
                                    </Content>
                                    <SeperateBar />
                                    <Content>
                                        <Field
                                            titleId="pageDashboard.drawerCategoriesField"
                                            css={InputItem}
                                            name="dropdownCateField"
                                            component={FormInputSelect as any}
                                            options={[
                                                { name: 'one', value: '1' },
                                                { name: 'two', value: '2' },
                                                { name: 'three', value: '3' }
                                            ]}
                                        />
                                        <Field
                                            name="input_switchEmptyCell"
                                            titleId="pageDashboard.drawerIncludeEmptyCells"
                                            component={FormInputSwitch as any}
                                        />
                                    </Content>
                                    <SeperateBar />
                                    <Content>
                                        <Field
                                            titleId="pageDashboard.drawerValues"
                                            css={InputItem}
                                            name="selectValues"
                                            component={FormInputSelectButton as any}
                                            options={[
                                                { name: formatMessage({ id: 'pageDashboard.drawerCount' }), value: '1' },
                                                { name: formatMessage({ id: 'pageDashboard.drawerField' }), value: '2' }
                                            ]}
                                        />
                                        <Field
                                            css={InputItem}
                                            name="dropdownProfit"
                                            component={FormInputSelect as any}
                                            options={[
                                                { name: 'one', value: '1' },
                                                { name: 'two', value: '2' },
                                                { name: 'three', value: '3' }
                                            ]}
                                        />
                                        <Field
                                            name="input_switchAggregate"
                                            titleId="pageDashboard.drawerAggregate"
                                            component={FormInputSwitch as any}
                                        />
                                    </Content>

                                    <Button css={ButtonStyle} onClick={() => { }} >
                                        <FormattedMessage id="pageDashboard.createBlock" />
                                    </Button>
                                </DrawerFrame>
                            </form>
                        )}
                    />
                }
            </Fragment>
        );
    }
}

export default injectIntl(DashboardDrawer);
